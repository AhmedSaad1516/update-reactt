
import'./loader.css'
function Loader(){
    return(

        <>
        
        <div id="lp-page-loader" >
           <span className="loader"></span>
           </div>
        </>
    )
}
export default Loader