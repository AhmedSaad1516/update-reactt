// import { Outlet } from 'react-router-dom';
// import SideBar from '../side-bar/sideBar';

// const MainLayout = () => {
//   return (
//     <div className="d-flex">
//       <div className="col-md-3">
//         <SideBar />
//       </div>
//       <div className="col-md-9 p-4">
//         <Outlet />
//       </div>
//     </div>
//   );
// };

// export default MainLayout;
