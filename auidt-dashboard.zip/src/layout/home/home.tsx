function Home() {
    return (
      <div className="w-100">
        <img className="w-100" src="../../../src/assets/image/Screenshot (250).png" alt="Screenshot" />
      </div>
    );
  }
  
  export default Home;
  